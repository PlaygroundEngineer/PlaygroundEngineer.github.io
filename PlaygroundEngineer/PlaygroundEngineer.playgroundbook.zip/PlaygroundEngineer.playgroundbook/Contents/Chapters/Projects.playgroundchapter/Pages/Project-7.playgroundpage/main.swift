//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

canvas.color = .white
var path = CGMutablePath()
func addPath() {
    path.move(to: canvas.currentTouchPoint)
    let p = canvas.currentTouchPoint
    let p1 = point(p.y, p.x)
    let p2 = point(p.x, -p.y)
    let p3 = point(-p.x, p.y)
    path.addLines(between: [p, p1, p2, p3])
}

canvas.onTouchDown = {
    canvas.removeAllChildren()
}

canvas.onTouchMoved = {
    addPath()
}
canvas.onTouchUp = {
    addPath()
    let node = ShapeNode(path: path)
    node.lineWidth = 0
    node.fillColor = randomColor()
    canvas.addChild(node)
    path = CGMutablePath()
}
