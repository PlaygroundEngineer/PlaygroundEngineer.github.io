//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

showGrid()

//create downtown
var totalWidth = 0
var startX = canvas.frame.minX
while totalWidth < Int(canvas.frame.maxX) * 2 {
    let width = random(50, 200)
    totalWidth += width
    let origin = CGPoint(x: startX, y: canvas.frame.minY + 300)
    let size = CGSize(width: width, height:  random(100, Int(canvas.frame.maxY)))
    let rect = CGRect(origin: origin, size: size)
    let building = ShapeNode(rect: rect)
    building.lineWidth = 0
    canvas.addChild(building)
    building.color = randomColor()
    startX += CGFloat(width)
}

let background = SpriteNode(gradient: [#colorLiteral(red: 0.0, green: 0.7790542245, blue: 0.9885957837, alpha: 1.0), #colorLiteral(red: 0.336129725, green: 0.06358888, blue: 0.1618391573, alpha: 1.0)], size: canvas.frame.size)
canvas.addChild(background)

canvas.onTouchUp = {
    let trunk = ShapeNode(rectOf: CGSize(width: 25, height: 150))
    trunk.position = canvas.currentTouchPoint
    trunk.color = .brown
    canvas.addChild(trunk)
    for i in 1 ... 2 {
        let leaf = ShapeNode(ellipseOf: CGSize(width: 25, height: 100))
        leaf.color = .green
        leaf.position = trunk.position
        canvas.addChild(leaf)
        if i == 2 {
            leaf.position.x += 50
            leaf.zRotation = -1.2
        } else {
            leaf.position.x -= 50
            leaf.zRotation = 1.2
        }
    }
}
