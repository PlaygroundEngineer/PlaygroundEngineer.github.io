//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code


import SpriteKit

setScene()

showGrid()

//create and return a path based on a list of points given in the input
func getPath(points: [CGPoint]) -> CGPath {
    let path = CGMutablePath()
    path.addLines(between: points)
    path.closeSubpath()
    return path
}

func wheel(spokes: Int, color: UIColor, points: [CGPoint]) -> ShapeNode {
   
    let path = getPath(points: points)
    
    let node = ShapeNode()
    var rotation = 0.0
    for i in 1...spokes {
        let line = ShapeNode(path: path)
        line.lineWidth = 10
        line.strokeColor = color
        line.zRotation = CGFloat(rotation)
        rotation += (2 * Double.pi) / Double(spokes)
        node.addChild(line)
    }
    return node
}

let p1 = CGPoint(x: -100, y: 0)
let p2 = CGPoint(x: 100, y: 0)
let node = wheel(spokes: 5, color: .green, points: [p1, p2])
canvas.addChild(node)


