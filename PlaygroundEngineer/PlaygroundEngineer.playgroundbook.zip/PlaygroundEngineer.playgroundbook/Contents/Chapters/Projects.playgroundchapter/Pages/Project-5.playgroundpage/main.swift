//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

showGrid()

func getPath(points: [CGPoint]) -> CGPath {
    let path = CGMutablePath()
    path.addLines(between: points)
    path.closeSubpath()
    return path
}

let rotateAction = SKAction.rotate(byAngle: 1.2, duration: 2.0)
let foreverAction = SKAction.repeatForever(rotateAction)

canvas.onTouchUp = {
    
    let p = canvas.currentTouchPoint
    let p1 = point(p.x - 150, 0)
    let p2 = point(0, p.y + 150)
    let points = [p, p1, p2]
    
    //create path using points array. use getPath(points: [CGPoint])
    
    //create shapeNode using the path created above
    
    //set shapeNode's color to random color
    
    //add shapeNode to the canvas
    
    //run forever action on the shapeNode
    
}


