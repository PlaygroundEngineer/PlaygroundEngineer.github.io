//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit
setScene()

var path = CGMutablePath()
var path2 = CGMutablePath()

let s1 = SKAction.scaleX(to: 0.5, duration: 0.8)
let s2 = SKAction.scaleX(to: 1.2, duration: 1.0)

let sequence = SKAction.sequence([s1, s2])
let forever = SKAction.repeatForever(sequence)

canvas.onTouchDown = {
    let p = canvas.currentTouchPoint
    path.move(to: .zero)
    let p1 = point(-p.x, p.y)
    path2.move(to: .zero)
}
canvas.onTouchMoved = {
    let p = canvas.currentTouchPoint
    path.addLine(to: p)
    let p1 = point(-p.x, p.y)
    path2.addLine(to: p1)
}
canvas.onTouchUp = {
    let p = canvas.currentTouchPoint
    path.addLine(to: p)
    let p1 = point(-p.x, p.y)
    path2.addLine(to: p1)
    
    path.addPath(path2)
    let node = ShapeNode(path: path)
    node.lineWidth = 1
    node.fillColor = randomColor()
    canvas.addChild(node)
    node.run(forever)
    
    path = CGMutablePath()
    path2 = CGMutablePath()
}
