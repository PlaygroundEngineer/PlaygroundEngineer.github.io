//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

var score = 0
var total = 10
var balloonCount = 0
let scoreLabel = addScore()

let waitAction = SKAction.wait(forDuration: 1.0)
let soundAction = SKAction.playSoundFileNamed(PlaygroundSound.click, waitForCompletion: true)
let createBalloon = SKAction.run {
    addBalloon()
}
let sequenceAction = SKAction.sequence([waitAction, createBalloon])
let startGameAction = SKAction.repeat(sequenceAction, count: total)

canvas.run(startGameAction)

func addBalloon() {
    let balloon = SpriteNode(image: #imageLiteral(resourceName: "Balloon.png"))
    balloon.size = CGSize(width: 120, height: 150)
    balloon.color = randomColor()
    balloon.position.x = random(-300, 300)
    balloon.position.y = -300
    canvas.addChild(balloon)
    balloonCount += 1
    if balloonCount == total {
        gameOver()
    }
    let moveAction = SKAction.move(to: point(balloon.position.x, 1000), duration: random(0.5, 3.0))
    balloon.run(moveAction)
    
    balloon.onTouchUp = {
        canvas.run(soundAction)
        balloon.removeFromParent()
        score = score + 1
    }
}

canvas.onTouchDown = {
    scoreLabel.text = "Score: \(score)            Missed: \(balloonCount - score) "
}

func gameOver() {
    let over = LabelNode(text: "Game Over")
    over.fontSize = 100
    let addLabel = SKAction.run {
        canvas.addChild(over)
    }
    let wait = SKAction.wait(forDuration: 3.0)
    let sequence = SKAction.sequence([wait, addLabel])
    canvas.run(sequence)
}

func addScore() -> SKLabelNode {
    let scoreLabel = LabelNode(text: "Score: 0")
    scoreLabel.position = point(0, 200)
    scoreLabel.fontName = Font.arialBoldMT
    scoreLabel.zPosition = 10
    canvas.addChild(scoreLabel)
    return scoreLabel
}
