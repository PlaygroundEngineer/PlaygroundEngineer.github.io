
import SpriteKit
import BookAPI

private var labelYPosition = 150.0
public func setMessage(text: String) {
    let labelNode = LabelNode(text: "\(text)")
    labelNode.position.y = CGFloat(labelYPosition)
    labelNode.fontSize = 30.0
    labelNode.fontName = Font.arialBoldMT
    canvas.addChild(labelNode)
    
    let fade = SKAction.fadeOut(withDuration: 10.0)
    labelNode.run(fade)
    labelYPosition -= 50.0
}


