//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

showGrid()

//: Create a function to add circle on the canvas
func addCircle() {
    let circle = ShapeNode(circleOfRadius: 50.0)
    circle.color = randomColor()
    circle.position = canvas.currentTouchPoint
    canvas.addChild(circle)
}

/*: Touch events
  1. OnTouchDown: Place the fingure on the iPad screen.
  2. OnTouchUp: Lift the fingure from iPad screen.
  3. OnTouchMoved: Move the fingure on iPad screen.
*/
canvas.onTouchDown = {
    addCircle()
}

canvas.onTouchUp = {
    
}

canvas.onTouchMoved = {
    
}
