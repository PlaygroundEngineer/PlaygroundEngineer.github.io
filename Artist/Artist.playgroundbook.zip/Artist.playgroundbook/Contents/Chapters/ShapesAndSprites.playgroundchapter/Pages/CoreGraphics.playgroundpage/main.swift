//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code


import SpriteKit

setScene()

showGrid()

//: CGFloat is a structure that stores a decimal number. Both Double and CGFloat store decimal numbers.
let number: CGFloat = 30.0
let decimalNumber: Double = 30.0

//: CGPoint is a structure that contains the x and y points in the coordinate system
let p = CGPoint(x: 100, y: 100)
p.x
p.y

//: CGSize is a structure that defines the height and the width
let s = CGSize(width: 200, height: 100)
s.width
s.height

//: CGRect is a structure that creates a rectangle
let r = CGRect(origin: p, size: s)
r.origin
r.maxX
r.contains(p)
r.height

//: CGPath is a class that creates a path
let path = CGPath(rect: r, transform: nil)

//: CGMutablePath is a class that creates a path which can be modified
let mutablePath = CGMutablePath()
mutablePath.move(to: .zero)
mutablePath.addLine(to: CGPoint(x: -200, y: 100))


