//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

//: Get CGSize from the canvas
let s = canvas.frame.size

//: Use SpriteNode class to create a gradient background
let gradientNode = SpriteNode(gradient: [#colorLiteral(red: 0.8899818659, green: 0.5725648999, blue: 0.9975566268, alpha: 1.0), #colorLiteral(red: 0.3248277307, green: 0.8369095325, blue: 0.9915711284, alpha: 1.0), #colorLiteral(red: 0.4653213024, green: 0.7332682014, blue: 0.2536376119, alpha: 1.0)], size: s)

//: Add SpriteNode to canvas
canvas.addChild(gradientNode)

//: Use SpriteNode with image input to create a butterfly SpriteNode
let butterfly = SpriteNode(image: #imageLiteral(resourceName: "butterfly-1.png"))

//: Adjust the properies of butterfly SpriteNode
butterfly.zRotation = 0.3
butterfly.zPosition = 2
butterfly.setScale(3.0)

//: Add butterfly to canvas
canvas.addChild(butterfly)



