//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

showGrid()

//: Create an instance of CGMutablePath class called c1
let c1 = CGMutablePath()

//: move(to:) function in CGMutablePath helps to move c1 to a starting point (-150, 0)
c1.move(to: point(-150, 0))

/*: Using addQuadCurve(to:control:) function, create a curve.
 The endpoint of the curve is (150, 0).
 Since the control point of the curve is (0, -150), curve bends towards the bottom of the canvas.
 */
c1.addQuadCurve(to: point(150, 0), control: point(0, -150))

//:Create an instance of ShapeNode class called curve and add it to the canvas
let curve = ShapeNode(path: c1)
curve.lineWidth = 4
canvas.addChild(curve)
