//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

/*: SKAction class is responsible for all animations.
Create a SKAction to scale the size of an object
 */
let scale = SKAction.scale(by: 2.0, duration: 1.0)

//: create a ShapeNode or SpriteNode
let node = ShapeNode(circleOfRadius: 50.0)
node.color = .green
canvas.addChild(node)

//: Apply the action on an instance of ShapeNode or SpriteNode using the run function
node.run(scale)
