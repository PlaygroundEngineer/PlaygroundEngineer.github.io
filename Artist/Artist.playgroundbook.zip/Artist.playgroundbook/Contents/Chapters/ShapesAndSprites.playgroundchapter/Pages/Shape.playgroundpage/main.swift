//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

//: import the SpriteKit framework so we can use the classes and structs inside it to create the art.
import SpriteKit

//: setScene() is a function that helps with setting initial scene with canvas.
setScene()

//: showGrid() is a function that shows the x, y coordinate space. 
showGrid()

/*:
 We use existing ShapeNode class to generate a circle shape.
 ShapeNode class can be used to create any shape

 "let" keyword describes that circle is a constant.
 
 The word "circle" is an identifier. It is user defined.
 That means you can replace the name of the identifier with any name you like. Make sure it is meaningful.
 
 The "circle" represents the ShapeNode class. The "circle" is of datatype ShapeNode. In short,
 "circle" is an instance of ShapeNode class.
 
 The ShapeNode is a class which helps creating various shapes.
 Paranthesis "()" helps in sending inputs to the class. Here, we are sending the circle radius as an input to the ShapeNode class.

 = is called an assignment operator.
 
 The statement below is called a declaration.
 */
let circle = ShapeNode(circleOfRadius: 50.0)

/*:
 "canvas" is a pre-defined identifier which is an instance of ShapeNode.

 It represents the main storyboard you use to draw on.
 
 addChild() is a function that belongs to ShapeNode. "()" allows you to send an input to the function. addChild() function allows you to add more ShapeNodes to canvas.
 
 */
canvas.addChild(circle)

