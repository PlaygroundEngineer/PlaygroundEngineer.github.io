//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

showGrid()

//: Create an instance of CGMutablePath class and name it "linePath"
let linePath = CGMutablePath()

/*:
move(to:) is a function in the CGMutablePath class.
This function helps to set the starting point of the drawing.
 CGPoint has a property called Zero. It returns CGPoint(x: 0, y:0)
 */
linePath.move(to: CGPoint.zero)

//: We are connecting 5 lines using points in the array xList and yList
let x = 100, y = 100
let xList = [x, x, -x, -x, y]
let yList = [y, -y, y, -y, x]
for i in 0 ... 4 {
    let point = CGPoint(x: xList[i], y: yList[i])
    linePath.addLine(to: point)
}

//: Use ShapeNode class to add linePath to the canvas
let shape = ShapeNode(path: linePath)
shape.lineWidth = 5
canvas.addChild(shape)
