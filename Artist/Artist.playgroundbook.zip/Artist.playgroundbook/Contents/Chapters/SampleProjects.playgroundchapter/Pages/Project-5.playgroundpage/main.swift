//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

canvas.color =  #colorLiteral(red: 0.5875531435, green: 0.8266115785, blue: 0.3729653656, alpha: 1.0)

var angle: CGFloat = 0.0
for i in 1 ... 8 {
    let petal = leaf(width: 50, height: 100, center: CGPoint(x: 0, y: 50))
    let petalNode = ShapeNode(path: petal)
    petalNode.color =  #colorLiteral(red: 0.8894588351, green: 0.1420151591, blue: 0.0, alpha: 1.0)
    petalNode.lineWidth = 0
    canvas.addChild(petalNode)
    
    let rotate = SKAction.rotate(byAngle: angle, duration: 1.0)
    angle += CGFloat((Double.pi * 2) / 8)
    petalNode.run(rotate)
}
