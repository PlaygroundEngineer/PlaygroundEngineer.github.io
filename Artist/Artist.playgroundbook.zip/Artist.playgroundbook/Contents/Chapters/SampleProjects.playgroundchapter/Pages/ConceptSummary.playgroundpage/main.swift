//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

showGrid()

//: Concepts covered in this course
//:--


/*:

 Framework: SpriteKit, CoreGraphics

 Primitive Data types: Int, Double, String, CGFloat

 Complex Data types: CGPoint, CGSize, CGRect, SKAction, UIColor, ShapeNode, SpriteNode, ButtonStack, Array, canvas

 Global functions: point(x,y), randomNumber(), randomColor(), getShapeNode(points: [CGPoint])

 Conditional and loops: If-elseIf-else ; for

 Functions, Inputs and outputs

 */
