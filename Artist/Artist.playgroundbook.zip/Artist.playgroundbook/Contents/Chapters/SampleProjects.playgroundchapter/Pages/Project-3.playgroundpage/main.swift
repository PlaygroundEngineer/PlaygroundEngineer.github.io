//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

canvas.color = #colorLiteral(red: 0.0, green: 0.9914394021, blue: 1.0, alpha: 1.0)
let rotate = SKAction.rotate(byAngle: CGFloat(Double.pi / 2), duration: 2.0)
let foreverRotate = SKAction.repeatForever(rotate)
canvas.onTouchDown = {
    let path = CGMutablePath()
    path.move(to: .zero)
    path.addQuadCurve(to: canvas.currentTouchPoint, control: point(100, 150))
    
    let node = ShapeNode(path: path)
    canvas.addChild(node)
    node.color = randomColor()
    node.run(foreverRotate)
}
