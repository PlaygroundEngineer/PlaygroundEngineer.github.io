//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

canvas.color =  #colorLiteral(red: 0.0, green: 0.3813630939, blue: 0.9982447028, alpha: 1.0)

var angle: CGFloat = 0.0
for i in 1 ... 30 {
    let petal = leaf(width: 50, height: 100, center: CGPoint(x: 0, y: 150))
    let petalNode = ShapeNode(path: petal)
    petalNode.color =  #colorLiteral(red: 0.9626445174, green: 0.9242319465, blue: 0.0, alpha: 1.0)
    petalNode.lineWidth = 0
    canvas.addChild(petalNode)
    
    let rotate = SKAction.rotate(byAngle: angle, duration: 1.0)
    angle += CGFloat((Double.pi * 2) / 30.0)
    petalNode.run(rotate)
}

let center = ShapeNode(circleOfRadius: 70)
center.color = #colorLiteral(red: 0.2351999581, green: 0.03076341376, blue: 0.1069220528, alpha: 1.0)
center.glowWidth = 70
center.strokeColor =  #colorLiteral(red: 0.2351999581, green: 0.03076341376, blue: 0.1069220528, alpha: 1.0)
canvas.addChild(center)
