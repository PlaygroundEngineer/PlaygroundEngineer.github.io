//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

setMessage(text: "move finger on screen")

var path = CGMutablePath()
func addPath() {
    path.move(to: .zero)
    path.addLine(to: canvas.currentTouchPoint)
}
canvas.onTouchMoved = {
    addPath()
}
canvas.onTouchUp = {
    addPath()
    let node = ShapeNode(path: path)
    node.lineWidth = 1
    canvas.addChild(node)
}
