//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

canvas.color = #colorLiteral(red: 0.2351999581, green: 0.03076341376, blue: 0.1069220528, alpha: 1.0)
let scaleOutOne = SKAction.scale(by: 1.3, duration: 1.0)
let scaleIn = SKAction.scale(by: 0.5, duration: 1.0)
let scaleOutTwo = SKAction.scale(to: 1.0, duration: 1.0)
let scale = SKAction.sequence([scaleOutOne, scaleIn, scaleOutTwo])
let scaleForever = SKAction.repeatForever(scale)

func addShape() {
    let path = CGMutablePath()
    path.move(to: .zero)
    path.addLine(to: canvas.currentTouchPoint)
    
    let lineNode = ShapeNode(path: path)
    lineNode.strokeColor = .white
    lineNode.lineWidth = 5
    canvas.addChild(lineNode)
    
    let headNode = ShapeNode(circleOfRadius: 15)
    headNode.position = canvas.currentTouchPoint
    headNode.color = .white
    lineNode.addChild(headNode)
    lineNode.run(scaleForever)
}

canvas.onTouchUp = {
    addShape()
}
