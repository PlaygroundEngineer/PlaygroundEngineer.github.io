//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

import SpriteKit

setScene()

setMessage(text: "Draw on screen")
setMessage(text: "Ask a friend to guess what you drew")
setMessage(text: "Lift the fingure from screen to reveal the drawing")

canvas.color =  #colorLiteral(red: 0.1804398894, green: 0.02673301287, blue: 0.2420461774, alpha: 1.0)

var points: [CGPoint] = []

canvas.onTouchUp = {
    let path = getShapeNode(for: points)
    path.lineWidth = 3.0
    canvas.addChild(path)
    points = []
}

canvas.onTouchMoved = {
    points.append(canvas.currentTouchPoint)
}
